URL_TO_MONITOR = "https://www.skipq.org"
url = ["https://www.skipq.org","https://www.realmadrid.com/en"]
URL_MONITOR_NAMESPACE = "Awais_WebHealth_Sprint2"
URL_MONITOR_NAME_AVAILABILITY = "url_availability"
URL_MONITOR_NAME_LATENCY = "url_latency"
