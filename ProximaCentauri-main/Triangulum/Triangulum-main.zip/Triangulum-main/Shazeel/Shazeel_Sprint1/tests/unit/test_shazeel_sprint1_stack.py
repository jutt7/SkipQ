import aws_cdk as core
import aws_cdk.assertions as assertions

from shazeel_sprint1.shazeel_sprint1_stack import ShazeelSprint1Stack

# example tests. To run these tests, uncomment this file along with the example
# resource in shazeel_sprint1/shazeel_sprint1_stack.py
def test_sqs_queue_created():
    app = core.App()
    stack = ShazeelSprint1Stack(app, "shazeel-sprint1")
    template = assertions.Template.from_stack(stack)

#     template.has_resource_properties("AWS::SQS::Queue", {
#         "VisibilityTimeout": 300
#     })
